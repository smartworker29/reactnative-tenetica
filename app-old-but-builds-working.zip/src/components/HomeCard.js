// @flow
import React, {PureComponent} from 'react'
import {
  View,
  ImageBackground,
  Image,
  StyleSheet,
  TouchableWithoutFeedback
} from 'react-native'
import IconIonicon from 'react-native-vector-icons/Ionicons'
import Slider from 'react-native-slider'

import Touchable from './Touchable'
import Text from './Text'
import {Metrics} from 'src/theme'
import {moderateScale} from 'src/utils/scaling'
import autobind from 'autobind-decorator'

const PADDING = 15

const styles = StyleSheet.create({
  bgImageContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    height: Metrics.screenWidth - moderateScale(PADDING)
  },
  bgImage: {
    width: Metrics.screenWidth - moderateScale(2 * PADDING),
    height: Metrics.screenWidth - moderateScale(2 * PADDING),
    justifyContent: 'space-between'
  },
  bgImageStyle: {
    borderRadius: moderateScale(20)
  },
  cardTop: {
    flexDirection: 'row',
    width: Metrics.screenWidth - moderateScale(2.5 * PADDING),
    alignItems: 'center',
    height: moderateScale(40 + 2 * PADDING)
  },
  avatarContainer: {
    width: moderateScale(40 + 2 * PADDING),
    alignItems: 'center'
  },
  avatar: {
    width: moderateScale(40),
    height: moderateScale(40),
    borderRadius: moderateScale(40),
    borderWidth: 1,
    borderColor: '#fff'
  },
  textTopContainer: {
    flex: 1
  },
  actionButton: {
    width: moderateScale(40),
    height: moderateScale(40),
    alignItems: 'center',
    justifyContent: 'center'
  },
  cardBottom: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    height: moderateScale(60),
    backgroundColor: 'rgba(0,0,0,0.3)',
    borderBottomLeftRadius: moderateScale(20),
    borderBottomRightRadius: moderateScale(20)
  },
  cardBottomInner: {
    width: Metrics.screenWidth - moderateScale(4 * PADDING),
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center'
  },
  comments: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-around',
    width: moderateScale(60)
  },
  slider: {
    width: Metrics.screenWidth / 2,
    height: moderateScale(60)
  },
  boldText: {
    fontWeight: '700'
  }
})

class HomeCard extends PureComponent {
  constructor(props) {
    super(props)
    this.state = {sliderValue: 0.6}
  }

  render() {
    const {
      backgroundUrl,
      author,
      totalSympathy,
      totalComments,
      place
    } = this.props

    return (
      <TouchableWithoutFeedback onPress={this.onPressCard}>
        <View style={styles.bgImageContainer}>
          <ImageBackground
            source={{uri: backgroundUrl}}
            style={styles.bgImage}
            imageStyle={styles.bgImageStyle}
          >
            <View style={styles.cardTop}>
              <View style={styles.avatarContainer}>
                <Image source={{uri: author.photoUrl}} style={styles.avatar} />
              </View>

              <View style={styles.textTopContainer}>
                <Text style={styles.boldText} reverse>
                  {author.fullName}
                </Text>
                <Text reverse small>
                  {place}
                </Text>
              </View>
              <Touchable
                onPress={() => {}}
                innerContainerStyle={styles.actionButton}
              >
                <IconIonicon name='ios-share-alt' color='#AEADB1' size={30} />
              </Touchable>
              <Touchable
                onPress={() => {}}
                innerContainerStyle={styles.actionButton}
              >
                <IconIonicon name='ios-bookmark' color='#AEADB1' size={30} />
              </Touchable>
            </View>

            <View style={styles.cardBottom}>
              <View style={styles.cardBottomInner}>
                <Slider
                  style={styles.slider}
                  value={this.state.sliderValue}
                  onValueChange={sliderValue =>
                    this.setState(() => ({sliderValue}))
                  }
                />

                <Text style={styles.boldText} reverse>
                  {Math.floor(totalSympathy / 1000)}K
                </Text>

                <Touchable innerContainerStyle={styles.comments}>
                  <IconIonicon
                    name='ios-chatbubbles'
                    color='#AEADB1'
                    size={30}
                  />
                  <Text style={styles.boldText} reverse>
                    {totalComments}
                  </Text>
                </Touchable>
              </View>
            </View>
          </ImageBackground>
        </View>
      </TouchableWithoutFeedback>
    )
  }

  @autobind
  onPressCard() {
    this.props.onPressCard()
  }
}

export default HomeCard
