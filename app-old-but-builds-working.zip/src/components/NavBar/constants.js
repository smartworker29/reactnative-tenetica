export const navItems = {
  profileIdx: 0,
  businessProfileIdx: 1,
  homeIdx: 2,
  exploreIdx: 3
}

export default {
  navItems
}
