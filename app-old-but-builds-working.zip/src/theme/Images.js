import LeonTanImage from 'src/assets/images/leon-tan-unsplash.jpg'
import CarsImage from 'src/assets/images/ashutosh-jangid-1214227-unsplash.jpg'

const images = {
  LeonTanImage,
  CarsImage
}

export default images
