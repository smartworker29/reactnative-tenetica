export default [
  {
    id: 1,
    name: 'Vivariums with Iguanas',
    data: [
      {
        id: 1,
        src: 'https://rcannon992.files.wordpress.com/2015/01/land-iguana-conolophus-subcristatus-galapagos-3.jpg',
        description: 'Green Iguana in a nice spacious Vivarium, Green Iguana in a nice spacious Vivarium, Green Iguana in a nice spacious Vivarium'
      },
      {
        id: 2,
        src: 'https://i.pinimg.com/236x/78/f3/67/78f36772c999f16c46a4a834f89dbc4f--green-iguana-reptiles-and-amphibians.jpg',
        description: 'Green Iguana in a nice spacious Vivarium'
      },
      {
        id: 3,
        src: 'https://i.amz.mshcdn.com/dfca7y3A6xBjOVbZgQPYsShONrc=/950x534/filters:quality(90)/https%3A%2F%2Fblueprint-api-production.s3.amazonaws.com%2Fuploads%2Fcard%2Fimage%2F687846%2F302e9c82-a5cc-45d3-8393-81c2130d571f.jpg',
        description: 'Green Iguana in a nice spacious Vivarium'
      }
    ]
  },
  {
    id: 2,
    name: 'Grooming',
    data: [
      {
        id: 1,
        src: 'http://animalhospitalatthecrossing.com/images/veterinary-images/champaign-illinois-veterinarian-grooming-2.jpg',
        description: 'Pretty Paws Dog Grooming Services'
      },
      {
        id: 2,
        src: 'https://petsaustralia.org/wp-content/uploads/2012/02/dogTEDDY3CROP-148x150.jpg',
        description: 'Pretty Paws Dog Grooming Services'
      },
      {
        id: 3,
        src: 'https://static1.squarespace.com/static/5a57c83012abd94e2ac59203/t/5a63d7048165f52495dcecb9/1516492567405/IMG_7816.jpg',
        description: 'Pretty Paws Dog Grooming Services'
      }
    ]
  },
  {
    id: 3,
    name: 'Sunday late night vets',
    data: [
      {
        id: 1,
        src: 'http://aavec.com/images/veterinary-images/24hr-emergency-vet-annapolis2-a.jpg',
        description: 'Green Iguana in a nice spacious Vivarium'
      },
      {
        id: 2,
        src: 'https://loansmart.co.nz/wp-content/uploads/2018/08/petbillloans.jpg',
        description: 'Green Iguana in a nice spacious Vivarium'
      },
      {
        id: 3,
        src: 'http://www.veterilandia.com/wp-content/uploads/2013/04/a-domicilio-OKCOPY-300x300.jpg',
        description: 'Green Iguana in a nice spacious Vivarium'
      }
    ]
  }
]
