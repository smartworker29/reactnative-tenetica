const defaultStackNavigatorConfig = {
  headerMode: 'none'
}

export default defaultStackNavigatorConfig
