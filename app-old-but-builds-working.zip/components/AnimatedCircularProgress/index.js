import CircularProgress from './CircularProgress'
import AnimatedCircularProgress from './AnimatedCircularProgress'

exports.AnimatedCircularProgress = AnimatedCircularProgress
exports.CircularProgress = CircularProgress
